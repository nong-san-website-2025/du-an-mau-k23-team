from django.contrib import admin
from .models import Seller

admin.site.register(Seller)
