import React from "react";
export default function WalletPage() {
  return (
    <div>
      <h2>Quản lý Ví Điện Tử</h2>
      {/* Table, filter, actions */}
      <div>Số dư, giao dịch, xác minh, bank liên kết...</div>
    </div>
  );
}
