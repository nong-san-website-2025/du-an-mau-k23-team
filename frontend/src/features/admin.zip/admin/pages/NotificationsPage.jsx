import React from "react";
export default function NotificationsPage() {
  return (
    <div>
      <h2>Quản lý Thông báo & Hệ thống</h2>
      {/* Table, filter, actions */}
      <div>Gửi thông báo, email, nhật ký hệ thống...</div>
    </div>
  );
}
