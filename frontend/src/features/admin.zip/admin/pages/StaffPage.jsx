import React from "react";
export default function StaffPage() {
  return (
    <div>
      <h2>Quản lý Nhân sự / Phân quyền</h2>
      {/* Table, filter, actions */}
      <div>Tạo tài khoản, gán quyền, nhật ký thao tác...</div>
    </div>
  );
}
