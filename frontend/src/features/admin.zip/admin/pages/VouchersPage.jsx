import React from "react";
export default function VouchersPage() {
  return (
    <div>
      <h2>Quản lý Voucher & Khuyến mãi</h2>
      {/* Table, filter, actions */}
      <div>Tạo mã, phân loại, quản lý lượt dùng, điều kiện...</div>
    </div>
  );
}
