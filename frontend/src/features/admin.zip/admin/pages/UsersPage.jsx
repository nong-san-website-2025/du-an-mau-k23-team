import React, { useState, useEffect } from "react";
import { Search, Plus, Import, FileUp, HelpCircle } from "lucide-react";
import AdminPageLayout from "../components/AdminPageLayout";
import AdminHeader from "../components/AdminHeader";
import UserFilterSidebar from "../components/UserAdmin/UserFilterSidebar";
import UserTable from "../components/UserAdmin/UserTable";
import UserTableActions from "../components/UserAdmin/UserTableActions";

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [checkedIds, setCheckedIds] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/users/");
      if (!res.ok) throw new Error("Network error");
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error("Lỗi khi fetch users:", err);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const baseClasses = "px-2 py-1 rounded-pill text-white fw-bold";
    switch (status) {
      case "Hoạt động":
        return `${baseClasses} bg-success`;
      case "Bị khóa":
        return `${baseClasses} bg-danger`;
      default:
        return `${baseClasses} bg-secondary`;
    }
  };

  return (
    <AdminPageLayout
      header={<AdminHeader />}
      sidebar={
        <UserFilterSidebar
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
        />
      }
    >
      <div className="bg-white" style={{ minHeight: "100vh" }}>
        {/* Header Section */}
        <div className="p-2 border-bottom">
          <div className="d-flex justify-content-between align-items-center mb-0 gap-2 flex-wrap">
            {/* Search */}
            <div style={{ flex: 1 }}>
              <div className="input-group" style={{ width: 420 }}>
                <span className="input-group-text bg-white border-end-0">
                  <Search size={18} />
                </span>
                <input
                  type="text"
                  className="form-control border-start-0"
                  placeholder="Tìm kiếm khách hàng..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ borderLeft: 0 }}
                />
              </div>
            </div>
            {/* Actions */}
            <div className="d-flex align-items-center gap-2 flex-shrink-0 mt-2 mt-md-0">
              {checkedIds.length > 0 && (
                <span
                  className="badge bg-primary"
                  style={{ fontSize: 14, fontWeight: 500 }}
                >
                  Đã chọn: {checkedIds.length}
                </span>
              )}
              {checkedIds.length > 0 ? (
                <button
                  className="btn btn-danger border"
                  style={{ fontWeight: "500" }}
                  title="Xoá khách hàng đã chọn"
                  onClick={() => {
                    if (
                      window.confirm(
                        `Bạn có chắc muốn xoá ${checkedIds.length} khách hàng đã chọn?`
                      )
                    ) {
                      alert(
                        "Đã gọi xoá các khách hàng: " +
                          checkedIds.join(", ")
                      );
                    }
                  }}
                >
                  <i
                    className="bi bi-trash"
                    style={{ fontSize: 16, marginRight: 6 }}
                  ></i>
                  Xoá ({checkedIds.length})
                </button>
              ) : (
                <>
                  <button
                    className="btn btn-light border"
                    style={{ fontWeight: "500", color: "#48474b" }}
                    title="Nhập file"
                  >
                    <Import size={16} />
                    &ensp; Nhập file
                  </button>
                  <button
                    className="btn btn-light border"
                    style={{ fontWeight: "500", color: "#48474b" }}
                    title="Xuất file"
                  >
                    <FileUp size={16} />
                    &ensp; Xuất file
                  </button>
                  <button
                    className="btn btn-light border"
                    style={{ fontWeight: "500", color: "#48474b" }}
                    title="Hướng dẫn sử dụng"
                  >
                    <HelpCircle size={16} />
                  </button>
                  <button
                    className="btn d-flex align-items-center"
                    style={{
                      backgroundColor: "#22C55E",
                      color: "#fff",
                      fontWeight: "600",
                      padding: "6px 20px",
                      borderRadius: "8px",
                      border: "none",
                    }}
                  >
                    <Plus size={20} className="me-2" style={{ fontSize: 16 }} />
                    Thêm khách hàng
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* User Table */}
        <div className="p-1">
          <UserTable
            users={users}
            loading={loading}
            searchTerm={searchTerm}
            getStatusBadge={getStatusBadge}
            UserTableActions={UserTableActions}
            checkedIds={checkedIds}
            setCheckedIds={setCheckedIds}
          />
          {/* Pagination */}
          <div className="d-flex justify-content-between align-items-center mt-4">
            <div className="text-muted">
              Hiển thị 1-5 trong tổng số {users.length} khách hàng
            </div>
            <nav aria-label="Pagination">
              <ul className="pagination mb-0">
                <li className="page-item disabled">
                  <span className="page-link">Trước</span>
                </li>
                <li className="page-item active">
                  <span
                    className="page-link"
                    style={{
                      backgroundColor: "#22C55E",
                      borderColor: "#22C55E",
                    }}
                  >
                    1
                  </span>
                </li>
                <li className="page-item">
                  <a
                    className="page-link"
                    href="#"
                    style={{ color: "#22C55E" }}
                  >
                    2
                  </a>
                </li>
                <li className="page-item">
                  <a
                    className="page-link"
                    href="#"
                    style={{ color: "#22C55E" }}
                  >
                    3
                  </a>
                </li>
                <li className="page-item">
                  <a
                    className="page-link"
                    href="#"
                    style={{ color: "#22C55E" }}
                  >
                    Sau
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </AdminPageLayout>
  );
}
