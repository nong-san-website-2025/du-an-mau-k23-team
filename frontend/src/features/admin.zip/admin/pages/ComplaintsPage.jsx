import React from "react";
export default function ComplaintsPage() {
  return (
    <div>
      <h2>Quản lý Khiếu nại / Tranh chấp</h2>
      {/* Table, filter, actions */}
      <div>Danh sách, xử lý, upload bằng chứng, lịch sử...</div>
    </div>
  );
}
