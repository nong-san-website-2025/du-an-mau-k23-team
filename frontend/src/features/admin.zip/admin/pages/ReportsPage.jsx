import React from "react";
export default function ReportsPage() {
  return (
    <div>
      <h2>Báo cáo - Thống kê nâng cao</h2>
      {/* Table, filter, actions */}
      <div>Doanh thu, tỷ lệ khiếu nại, chuyển đổi, export...</div>
    </div>
  );
}
