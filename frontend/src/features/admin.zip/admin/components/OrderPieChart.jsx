import React from "react";
// Dummy chart, replace with chart lib
export default function OrderPieChart() {
  return (
    <div style={{width:400, height:300, background:'#f3f4f6', borderRadius:12, padding:16}}>
      <h4>Tỷ lệ đơn hủy</h4>
      <div style={{height:220, background:'#fff', borderRadius:8, boxShadow:'0 2px 8px #0001'}}>
        {/* Pie chart here */}
        <span style={{color:'#888'}}>Pie Chart Placeholder</span>
      </div>
    </div>
  );
}
