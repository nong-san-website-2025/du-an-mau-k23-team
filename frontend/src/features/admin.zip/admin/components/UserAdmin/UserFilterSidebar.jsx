export default function UserFilterSidebar() {
    return <div>Sidebar khách hàng</div>;
}
