import React from "react";

export default function UserTableRow({
  user,
  checked,
  onCheck,
  onExpand,
  getStatusBadge,
  isExpanded,
}) {
  return (
    <tr style={{ borderBottom: "1px solid #e5e7eb" }}>
      <td className="align-middle">
        <input
          type="checkbox"
          className="form-check-input"
          checked={checked}
          onChange={onCheck}
        />
      </td>
      <td className="align-middle" style={{ fontSize: "14px", fontWeight: 500 }}>
        {user.username}
      </td>
      <td className="align-middle" style={{ fontSize: "14px" }}>
        {user.email}
      </td>
      <td className="align-middle" style={{ fontSize: "14px" }}>
        {/* Nếu có trường phone */}
        {user.phone || ""}
      </td>
      <td className="align-middle" style={{ fontSize: "14px" }}>
        {user.role ? user.role.name : ""}
      </td>
      <td className="align-middle">
        {getStatusBadge ? getStatusBadge(user.status) : ""}
      </td>
      <td className="align-middle">
        <button
          className="btn btn-sm btn-outline-secondary"
          onClick={onExpand}
        >
          {isExpanded ? "Ẩn" : "Chi tiết"}
        </button>
      </td>
    </tr>
  );
}