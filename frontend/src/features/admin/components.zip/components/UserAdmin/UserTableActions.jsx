// import React, { useState } from "react";

// const UserList = () => {
//   // Dữ liệu user mẫu
//   const [users] = useState([
//     { id: 1, name: "Nguyễn Văn A", email: "a@example.com" },
//     { id: 2, name: "Trần Thị B", email: "b@example.com" },
//     { id: 3, name: "Lê Văn C", email: "c@example.com" }
//   ]);

//   return (
//     <div style={{ padding: "20px" }}>
//       <h2>Danh sách người dùng</h2>
//       <ul>
//         {users.map((user) => (
//           <li key={user.id}>
//             <strong>{user.name}</strong> - {user.email}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default UserList;
