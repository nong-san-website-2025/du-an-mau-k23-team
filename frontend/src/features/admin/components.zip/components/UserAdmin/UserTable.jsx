import React, { useState } from "react";
import { userApi } from "../../services/userApi";
import UserTableRow from "./UserTableRow";
import UserDetailRow from "./UserDetailRow";
import UserEditForm from "./UserEditForm";

export default function UserTable({
  users,
  loading,
  selectedRole,
  searchTerm,
  getStatusBadge,
  checkedIds,
  setCheckedIds,
}) {
  console.log("UserTable users:", users);
  const [expandedUserId, setExpandedUserId] = useState(null);
  const [loadingAction, setLoadingAction] = useState(false);
  const [editUser, setEditUser] = useState(null);

  const handleExpand = (userId) => {
    setExpandedUserId(expandedUserId === userId ? null : userId);
    setEditUser(null);
  };

  const handleDelete = async (user) => {
    if (!window.confirm(`Bạn có chắc muốn xoá người dùng "${user.name}"?`))
      return;
    setLoadingAction(true);
    try {
      await userApi.deleteUser(user.id);
      alert("Đã xoá người dùng thành công!");
      window.location.reload();
    } catch (err) {
      alert("Xoá người dùng thất bại!");
    } finally {
      setLoadingAction(false);
    }
  };

  const handleEdit = (user) => {
    setEditUser(user);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setLoadingAction(true);
    try {
      const form = e.target;
      const data = {
        name: form.name.value,
        email: form.email.value,
        role: form.role.value,
        status: form.status.value,
      };
      await userApi.updateUser(editUser.id, data);
      alert("Cập nhật người dùng thành công!");
      setEditUser(null);
      window.location.reload();
    } catch (err) {
      alert("Cập nhật thất bại!");
    } finally {
      setLoadingAction(false);
    }
  };

  // Filter users
  const filteredUsers = users.filter((user) => {
    const roleMatch =
      selectedRole === "all" ||
      (user.role && String(user.role.id) === selectedRole) ||
      (!user.role && selectedRole === "none");

    const searchMatch =
      (user.username && user.username.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()));

    return roleMatch && searchMatch;
  });

  return (
    <div className="table-responsive" style={{ maxHeight: "70vh", overflowY: "auto" }}>
      <table className="table table-hover" style={{ margin: 0 }}>
        <thead>
          <tr style={{ borderBottom: "2px solid #e5e7eb" }}>
            <th className="border-0 py-0" style={{ position: "sticky", top: 0, zIndex: 5, background: "#fff" }}>
              <input
                type="checkbox"
                className="form-check-input"
                checked={users.length > 0 && checkedIds.length === filteredUsers.length}
                onChange={(e) => {
                  const visibleIds = filteredUsers.map((u) => u.id);
                  if (e.target.checked) {
                    setCheckedIds(Array.from(new Set([...checkedIds, ...visibleIds])));
                  } else {
                    setCheckedIds(checkedIds.filter((id) => !visibleIds.includes(id)));
                  }
                }}
              />
            </th>
            <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Tên</th>
            <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Email</th>
            {/* <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Số điện thoại</th> */}
            <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Vai trò</th>
            <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Trạng thái</th>
            <th className="border-0 py-0" style={{ fontSize: "12px", fontWeight: "500" }}>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td colSpan={6} className="text-center text-muted">Đang tải dữ liệu...</td>
            </tr>
          ) : filteredUsers.length === 0 ? (
            <tr>
              <td colSpan={6} className="text-center text-muted">Không có người dùng</td>
            </tr>
          ) : (
            users.map((user) => (
              <React.Fragment>
                <UserTableRow
                   key={user.id} user={user}
                  checked={checkedIds.includes(user.id)}
                  onCheck={(e) => {
                    if (e.target.checked) {
                      setCheckedIds([...checkedIds, user.id]);
                    } else {
                      setCheckedIds(checkedIds.filter((id) => id !== user.id));
                    }
                  }}
                  onExpand={() => handleExpand(user.id)}
                  getStatusBadge={getStatusBadge}
                  isExpanded={expandedUserId === user.id}
                />
                {expandedUserId === user.id && (
                  <UserDetailRow
                    user={user}
                    getStatusBadge={getStatusBadge}
                    onEdit={() => handleEdit(user)}
                    onDelete={() => handleDelete(user)}
                    loadingAction={loadingAction}
                    isEditing={editUser && editUser.id === user.id}
                  >
                    {editUser && editUser.id === user.id && (
                      <UserEditForm
                        editUser={editUser}
                        loadingAction={loadingAction}
                        onSubmit={handleEditSubmit}
                        onCancel={() => setEditUser(null)}
                      />
                    )}
                  </UserDetailRow>
                )}
              </React.Fragment>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
