import React from "react";

export default function UserEditForm({
  editUser,
  loadingAction,
  onSubmit,
  onCancel,
}) {
  return (
    <form onSubmit={onSubmit}>
      <div className="mb-2">
        <label className="form-label">Tên</label>
        <input
          type="text"
          name="name"
          defaultValue={editUser.name}
          className="form-control"
          required
        />
      </div>
      <div className="mb-2">
        <label className="form-label">Email</label>
        <input
          type="email"
          name="email"
          defaultValue={editUser.email}
          className="form-control"
          required
        />
      </div>
      <div className="mb-2">
        <label className="form-label">Vai trò</label>
        <select
          name="role"
          defaultValue={editUser.role}
          className="form-select"
        >
          <option value="admin">Admin</option>
          <option value="staff">Nhân viên</option>
          <option value="customer">Khách hàng</option>
        </select>
      </div>
      <div className="mb-2">
        <label className="form-label">Trạng thái</label>
        <select
          name="status"
          defaultValue={editUser.status}
          className="form-select"
        >
          <option value="active">Hoạt động</option>
          <option value="inactive">Ngừng</option>
        </select>
      </div>
      <div className="mt-2">
        <button
          type="submit"
          className="btn btn-success me-2"
          disabled={loadingAction}
        >
          Lưu
        </button>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={onCancel}
          disabled={loadingAction}
        >
          Huỷ
        </button>
      </div>
    </form>
  );
}
