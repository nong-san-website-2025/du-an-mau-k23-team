import React from "react";

export default function UserDetailRow({
  user,
  getStatusBadge,
  onEdit,
  onDelete,
  loadingAction,
  isEditing,
  children,
}) {
  return (
    <tr style={{ background: "#f9fafb" }}>
      <td colSpan={6}>
        {!isEditing ? (
          <div>
            <p><strong>Tên:</strong> {user.name}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Vai trò:</strong> {user.role}</p>
            <p><strong>Trạng thái:</strong> {getStatusBadge(user.status)}</p>
            <div className="mt-2">
              <button
                className="btn btn-sm btn-primary me-2"
                onClick={onEdit}
                disabled={loadingAction}
              >
                Sửa
              </button>
              <button
                className="btn btn-sm btn-danger"
                onClick={onDelete}
                disabled={loadingAction}
              >
                Xoá
              </button>
            </div>
          </div>
        ) : (
          children
        )}
      </td>
    </tr>
  );
}
