import React from "react";
export default function OrdersPage() {
  return (
    <div>
      <h2>Quản lý Đơn hàng</h2>
      {/* Table, filter, actions */}
      <div>Danh sách, chi tiết, trạng thái, can thiệp, cảnh báo...</div>
    </div>
  );
}
