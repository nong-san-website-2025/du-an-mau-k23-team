import React from "react";
export default function ShopsPage() {
  return (
    <div>
      <h2>Quản lý Shop</h2>
      {/* Table, filter, actions */}
      <div>Duyệt shop, vô hiệu hóa, gắn tag, xem sản phẩm...</div>
    </div>
  );
}
