// pages/UsersPage.jsx
import React, { useEffect, useState } from "react";
import { Search, Plus, Import, FileUp, HelpCircle } from "lucide-react";
import AdminPageLayout from "../components/AdminPageLayout";
import AdminHeader from "../components/AdminHeader";
import UserSideBar from "../components/UserAdmin/UserSidebar";
import UserTable from "../components/UserAdmin/UserTable";
import UserTableActions from "../components/UserAdmin/UserTableActions";

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRole, setSelectedRole] = useState("");
  const [roles, setRoles] = useState([]);
  const [checkedIds, setCheckedIds] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      setUsers(Array.isArray(data) ? data : []);

      const uniqueRoles = [...new Set(data.map((u) => u.role).filter(Boolean))];
      setRoles(uniqueRoles);
    } catch (err) {
      console.error("Lỗi khi fetch users:", err);
      setUsers([]);
      setRoles([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminPageLayout
      header={<AdminHeader />}
      sidebar={
        <UserSideBar
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          selectedRole={selectedRole}
          setSelectedRole={setSelectedRole}
          roles={roles}
          onRoleCreated={fetchUsers}
        />
      }
    >
      <div className="bg-white" style={{ minHeight: "100vh" }}>
        {/* Header */}
        <div className="p-2 border-bottom">
          <div className="d-flex justify-content-between align-items-center mb-0 gap-2 flex-wrap">
            {/* Tìm kiếm */}
            <div style={{ flex: 1 }}>
              <div className="input-group" style={{ width: 420 }}>
                <span className="input-group-text bg-white border-end-0">
                  <Search size={18} />
                </span>
                <input
                  type="text"
                  className="form-control border-start-0"
                  placeholder="Tìm kiếm người dùng..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ borderLeft: 0 }}
                />
              </div>
            </div>
            {/* Action buttons */}
            <div className="d-flex align-items-center gap-2 flex-shrink-0 mt-2 mt-md-0">
              {checkedIds.length > 0 ? (
                <button
                  className="btn btn-danger border"
                  onClick={() => {
                    if (window.confirm(`Xoá ${checkedIds.length} người dùng?`)) {
                      alert("Đã xoá: " + checkedIds.join(", "));
                    }
                  }}
                >
                  Xoá ({checkedIds.length})
                </button>
              ) : (
                <>
                  <button className="btn btn-light border">
                    <Import size={16} /> Nhập file
                  </button>
                  <button className="btn btn-light border">
                    <FileUp size={16} /> Xuất file
                  </button>
                  <button className="btn btn-light border">
                    <HelpCircle size={16} />
                  </button>
                  <button
                    className="btn"
                    style={{
                      backgroundColor: "#22C55E",
                      color: "#fff",
                      fontWeight: "600",
                    }}
                  >
                    <Plus size={20} className="me-2" /> Thêm người dùng
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* User Table */}
        <div className="p-1">
          <UserTable
            users={users}
            loading={loading}
            selectedRole={selectedRole}
            searchTerm={searchTerm}
            UserTableActions={UserTableActions}
            checkedIds={checkedIds}
            setCheckedIds={setCheckedIds}
          />
        </div>
      </div>
    </AdminPageLayout>
  );
}
