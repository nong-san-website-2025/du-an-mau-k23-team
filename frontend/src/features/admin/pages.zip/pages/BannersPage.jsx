import React from "react";
export default function BannersPage() {
  return (
    <div>
      <h2>Quản lý Banner, Quảng cáo</h2>
      {/* Table, filter, actions */}
      <div>Quản lý banner, lên lịch, kiểm duyệt quảng cáo...</div>
    </div>
  );
}
